

<?php $__env->startSection('content'); ?>



  

<div class="ui-container-large">
  <div class="container">
    <form id="searchForm" action="<?php echo e(url('post/search')); ?>" method="post">
      <div class="d-flex flex-row-reverse">
          <?php echo csrf_field(); ?>
          <div class="flex-row">
              <div class="btn btn-primary btn-sm"
              onclick="document.getElementById('searchForm').submit()"
              ><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                  <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
                </svg></div>
              <div class="btn btn-success btn-sm addCategoryButton"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-square-fill mr-2" viewBox="0 0 16 16">
                  <path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm6.5 4.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3a.5.5 0 0 1 1 0z"/>
                </svg>Qo'shish</div>
              
          </div>
              <div class="m-2">
                  <input type="text" name="title"  placeholder="Sarlavha bo'yicha" class="input-style-1"
                  <?php if(!empty($request['title'])): ?>
                      value="<?php echo e($request['title']); ?>"
                  <?php endif; ?>
                  >
              </div>
              <div class="m-2">
                  <input type="text" name="author"  placeholder="Avtor bo'yicha" class="input-style-1"
                  <?php if(!empty($request['author'])): ?>
                  value="<?php echo e($request['author']); ?>"
              <?php endif; ?>
                  >
              </div>
              <div class="m-2">
                <select name="category" class="input-style-1">
                  <option value="0" selected>Kategoriya bo'yicha</option>
                  <optgroup label="Kategoriyalar">
                    <?php if(!empty($request['category'])): ?>
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($category->id); ?>"
                        <?php if($category->id == $request['category']): ?>
                            selected
                        <?php endif; ?>
                        ><?php echo e($category->title); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </optgroup>
                
                </select>
               </div>
            </div>
          </form>
  </div>
    <hr>
    <div class="container ">
        
        
        <div id="ex1" class="createModal mymodal modal">
            <form action="<?php echo e(route('post.store')); ?>" id="categoryCreate" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
            <div class="kulrang py-1" style="text-align: center;font-size:20px;">Post qo'shish</div>
            <div class="content mx-3 mt-3 d-flex flex-column">
              <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Sarlavha:</div>
                <input type="text" name="title" id="title"  class="input-style-1 mt-2 col-8" >
              </div>
               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Betlari:</div>
                <input type="number" name="pages" id="pages"  class="input-style-1 mt-2 col-8" >
               </div>
               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Avtor:</div>
                <input type="text" name="author" id="author"  class="input-style-1 mt-2 col-8" >
               </div>
               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Email:</div>
                <input type="text" name="email" id="email"  class="input-style-1 mt-2 col-8" >
               </div>
               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Telefoni:</div>
                <input type="phone" name="phone" id="phone"  class="input-style-1 mt-2 col-8" >
               </div>
               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Tili:</div>
                <select name="language" id="language" class="input-style-1 mt-2 col-8">
                  <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($language->id); ?>"><?php echo e($language->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
               </div>
               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Kategoriyasi:</div>
                <select name="category_id" id="category_id" class="input-style-1 mt-2 col-8">
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
               </div>

               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Fayl:</div>
                <input type="file" name="sample" id="sample"  class="input-style-1 mt-2 col-8" >
               </div>

            </div>
            <hr>
            <div class="d-flex justify-content-around">
                    <div class="btn btn-danger close_modal">Chiqish</div>
                    <div class="btn btn-primary" onclick="document.getElementById('categoryCreate').submit()">Saqlash</div>
            </div>
             </div>
            </form>
          </div>
          
        <div id="ex1" class="updateModal mymodal modal">
            <form action="<?php echo e(url('post/updatePost')); ?>" id="postUpdate" method="post"  enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" id="id_edit">
            <div class="kulrang py-1" style="text-align: center;font-size:20px;">Post qo'shish</div>
            <div class="content mx-3 mt-3 d-flex flex-column">
              <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Sarlavha:</div>
                <input type="text" name="title" id="title_edit"  class="input-style-1 mt-2 col-8" >
              </div>
               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Betlari:</div>
                <input type="number" name="pages" id="pages_edit"  class="input-style-1 mt-2 col-8" >
               </div>
               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Avtor:</div>
                <input type="text" name="author" id="author_edit"  class="input-style-1 mt-2 col-8" >
               </div>
               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Email:</div>
                <input type="text" name="email" id="email_edit"  class="input-style-1 mt-2 col-8" >
               </div>
               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Telefoni:</div>
                <input type="phone" name="phone" id="phone_edit"  class="input-style-1 mt-2 col-8" >
               </div>
               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Tili:</div>
                <select name="language" id="language_edit" class="input-style-1 mt-2 col-8">
                  <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($language->id); ?>"><?php echo e($language->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
               </div>
               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Kategoriyasi:</div>
                <select name="category_id" id="category_id_edit" class="input-style-1 mt-2 col-8">
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
               </div>

               <div class="row col">
                <div class="text-design1 ui-text-5x col-4 mt-2">Fayl:</div>
                <input type="file" name="sample" id="sample_edit"  class="input-style-1 mt-2 col-8" >
               </div>

            </div>
            <div >
            <hr>
            <div class="d-flex justify-content-around">
                    <div class="btn btn-danger close_modal">Chiqish</div>
                    <div class="btn btn-primary" onclick="document.getElementById('postUpdate').submit()">Yangilash</div>
            </div>
             </div>
            </form>
          </div>
           
        <div id="ex1" class="deleteModal mymodal modal">
            <form action="<?php echo e(url('post/deletePost')); ?>" id="postDelete" method="post">
                <?php echo csrf_field(); ?>
            <div class="kulrang py-1" style="text-align: center;font-size:20px;">Kategoriyani O'chirmoqchimisiz?</div>
            
            <div class="mt-5">
            <input type="hidden" name="id" id="post_delete">
            <div class="d-flex justify-content-around">
                    <div class="btn btn-primary close_modal">Chiqish</div>
                    <div class="btn btn-danger" onclick="document.getElementById('postDelete').submit()">O'chirish</div>
            </div>
             </div>
            </form>
          </div>

          

          <?php if($posts->count() != 0): ?>
          <div class="list-group">
            <a href="#" class="list-group-item list-group-item-action" style="background-color: black;color:white">
              Postlar
            </a>
            
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="list-group-item list-group-item-action myElementsList">
                <div class="row">
                    <div class="col-10 ml-2" onclick="location.href='<?php echo e(route('post.show',$post->id)); ?>'" >
                        <div class="row font-weight-bold"><?php echo e($post->title); ?></div>
                        <div class="row">
                            <?php if(strlen($post->body) == 0): ?>
                                Postda Kontent qo'yilmagan
                            <?php else: ?>
                                <?php echo e(substr($post->body, 0, 90)); ?>...
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col">
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-person-fill text-secondary" viewBox="0 0 16 16"><path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
                                  </svg>
                              <span class="mr-3 ml-1 text-secondary" style="font-size: 12px;"><?php echo e($post->author); ?></span>
                              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-calendar-event text-secondary" viewBox="0 0 16 16">
                                <path d="M11 6.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z"/>
                                <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z"/>
                              </svg>
                              <span class="mr-3 ml-1 text-secondary" style="font-size: 12px;"><?php echo e($post->created_at); ?></span>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-2 row buttonEdits">
                      <button type="button"   
                      <?php if(!empty($post->sample)): ?>
                      class="btn btn-success btn-sm col"
                      onclick="location.href='<?php echo e(asset('storage/'.$post->sample)); ?>'"
                      <?php else: ?>
                      class="btn btn-secondary btn-sm col"
                      <?php endif; ?>
                      ><i class="far fa-file-alt"></i></button> 
                            <button type="button" class="btn btn-primary btn-sm col"  onclick="editPost(<?php echo e($post->id); ?>)" ><i class="fas fa-edit"></i></button> 
                          <button type="button" class="btn btn-danger btn-sm col" onclick="deletePost(<?php echo e($post->id); ?>)"><i class="fas fa-trash-alt"></i></button>
                      
                    </div>
                </div>
              </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            
          </div>
      
     
          <?php else: ?>
          <div class="d-flex justify-content-center m-5" style="font-size: 25px;color:grey">No data</div>
          <?php endif; ?>
          
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
<style>
  
.input-style-1 {
    height:30px;
    border: none;
    background: hsl(0 0% 93%);
    border-radius: .25rem;
    &[type="submit"] {
      background: hotpink;
      color: white;
      box-shadow: 0 .75rem .5rem -.5rem hsl(0 50% 80%);
    }
    
  }
  .input-style-1:focus{
    outline: none !important;
    border:1px solid rgb(224, 224, 224);
  }
  .modal{
      max-height:250px!important;
  }

  .createModal{
      max-height:460px!important;
  }
  .updateModal{
      max-height:460px!important;
  }
  .deleteModal{
      max-height:50px!important;
  }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script>
$('.addCategoryButton').click(function(event) {
  $('.createModal').modal();
});

function editPost(id){
    $.ajax({
        type: 'POST',
    data: {
     'id': id,
     '_token':"<?php echo e(csrf_token()); ?>" //pass CSRF
          },
    enctype: 'multipart/form-data',
    url: "<?php echo e(url('post/getById')); ?>",
    success: function (data) {
        console.log(data.id);   
        $('#id_edit').val(id);
         $('#title_edit').val(data.title);
         $('#pages_edit').val(data.pages);
         $('#author_edit').val(data.author);
         $('#email_edit').val(data.email);
         $('#phone_edit').val(data.phone);

         $('#language_edit').val(data.language).change();
         $('#category_id_edit').val(data.category_id).change();

         if(data.sample==""){
          $('#sample_edit').val(data.sample);
}
        
         $('.updateModal').modal();
    }
});

};

function deletePost(id){
    $('#post_delete').val(id);
    $('.deleteModal').modal();
}
$('.new_badge').text('<?php echo e($new_count); ?>');
$('.newpost').addClass('active');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/dashboard/blogpost/blogpost/resources/views/src/newposts.blade.php ENDPATH**/ ?>