$('.close_modal').click(function(event) {
    $.modal.close();
  });